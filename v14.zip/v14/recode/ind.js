exports.paymentstore = (owner) => {
return `*UDH GA JUALAN KAK UANG DAH banyak*

Wa.me/${owner}
`
}

